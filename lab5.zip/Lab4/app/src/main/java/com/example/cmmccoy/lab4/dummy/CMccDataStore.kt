package com.example.cmmccoy.lab4.dummy

import java.util.ArrayList
import java.util.HashMap

/**
 * Helper class for providing sample content for user interfaces created by
 * Android template wizards.
 *
 * TODO: Replace all uses of this class before publishing your app.
 */
object CMccDataStore {

    /**
     * An array of sample (dummy) items.
     */
    val ITEMS: MutableList<playerItem> = ArrayList()

    /**
     * A map of sample (dummy) items, by ID.
     */
    val ITEM_MAP: MutableMap<String, playerItem> = HashMap()

    init {

    }

    private fun addItem(item: playerItem) {
        ITEMS.add(item)
        ITEM_MAP.put(item.name, item)
    }

    public fun createPlayer(name: String, num: Int, pos: String, captain: Boolean){
        val player = playerItem(name, num, pos, captain)
        addItem(player)
    }


    /**
     * A dummy item representing a piece of content.
     */
    data class playerItem(val name: String, val num: Int, val pos: String, val captain: Boolean) {
        override fun toString(): String = name
    }
}
