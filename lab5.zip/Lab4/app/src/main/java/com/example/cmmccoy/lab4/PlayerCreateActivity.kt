package com.example.cmmccoy.lab4

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.example.cmmccoy.lab4.dummy.CMccDataStore
import kotlinx.android.synthetic.main.create_player.*

class PlayerCreateActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.create_player)

        playerSubmit.setOnClickListener{
            val captain = playerCaptain.isChecked
            val pos = playerNum.text
            val name = inputPlayerName.text
            val num = playerNum.text

            //CMccDataStore.createPlayer(name, num, pos, captain)
        }
    }
}