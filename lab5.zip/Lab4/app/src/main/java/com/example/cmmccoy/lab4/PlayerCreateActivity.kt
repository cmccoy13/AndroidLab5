package com.example.cmmccoy.lab4

import android.content.Intent
import android.os.Bundle
import android.support.v4.app.NavUtils
import android.support.v7.app.AppCompatActivity
import com.example.cmmccoy.lab4.dummy.CMccDataStore
import kotlinx.android.synthetic.main.create_player.*

class PlayerCreateActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.create_player)

        playerSubmit.setOnClickListener{
            val name = playerName.text.toString()
            //val num = playerNum.text
            val num = Integer.parseInt(playerNum.text.toString())
            val pos = playerPosition.text.toString()
            val captain = playerCaptain.isChecked

            CMccDataStore.createPlayer(name, num, pos, captain)

            NavUtils.navigateUpTo(this, Intent(this, ItemListActivity::class.java))
            true
        }
    }
}